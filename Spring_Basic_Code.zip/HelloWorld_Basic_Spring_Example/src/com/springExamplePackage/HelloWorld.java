package com.springExamplePackage;
public class HelloWorld {
	private String message;
	public void setMessage(String message){
		this.message = message;
	}
	public void getMessage(){
		System.out.println("your Message :" +message);
	}
}