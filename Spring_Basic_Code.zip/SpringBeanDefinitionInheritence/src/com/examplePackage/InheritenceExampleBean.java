package com.examplePackage;

public class InheritenceExampleBean {

	public int type;
	public String action;
	public String Country;
	
	public void  setType(int type){
		this.type = type;
	}
	
	public void  setAction(String action){
		this.action = action;
	}
	
	public void  setCountry(String country){
		this.Country = country;
	}
	
}
