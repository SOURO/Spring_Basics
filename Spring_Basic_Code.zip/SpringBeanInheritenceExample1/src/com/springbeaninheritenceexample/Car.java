package com.springbeaninheritenceexample;

public class Car {

	private String colour;

	private Long price;

	private String brand;

	public String getColour() {

		return colour;

	}

	public void setColour(String colour) {

		this.colour = colour;

	}

	public Long getPrice() {

		return price;

	}

	public void setPrice(Long price) {

		this.price = price;

	}

	public String getBrand() {

		return brand;

	}

	public void setBrand(String brand) {
		this.brand = brand;
	}
}
