package com.factorypatternexample;

public class UserService {
	 public UserService() {
		  System.out.println("Initialising UserService.");
	  }
}
