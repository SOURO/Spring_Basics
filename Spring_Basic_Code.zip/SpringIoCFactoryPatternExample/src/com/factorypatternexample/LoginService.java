package com.factorypatternexample;

public class LoginService {
	public LoginService(){
		System.out.println("Initialising LoginService.");
	}
}
