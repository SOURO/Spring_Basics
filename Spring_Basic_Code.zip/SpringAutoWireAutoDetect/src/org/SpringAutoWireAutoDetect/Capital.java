package org.SpringAutoWireAutoDetect;
  
public class Capital {  
  
    String capitalName;  
  
    public String getCapitalName() {  
        return capitalName;  
    }  
  
    public void setCapitalName(String capitalName) {  
        this.capitalName = capitalName;  
    }  
}