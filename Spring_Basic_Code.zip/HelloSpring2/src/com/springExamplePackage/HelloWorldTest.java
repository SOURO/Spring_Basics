package com.springExamplePackage;

import static org.junit.Assert.*;
import org.junit.*;

import org.junit.Test;

public class HelloWorldTest {

	@Test
	public void testSetMessage() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMessage() {
		fail("Not yet implemented");
	}

}
