package com.springdibyinterfaceexample;

public class MyService {
		private Text text;
	 
	   public Text getText() {
	       return text;
	   }

	   public void setText(Text text) {
	       this.text = text;
	   }
}
