package com.springdibyinterfaceexample;

public class MyText implements Text{
	private String textString;

	   public String getTextString() {
	       return textString;
	   }

	   public void setTextString(String textString) {
	       this.textString = textString;
	   }
}
