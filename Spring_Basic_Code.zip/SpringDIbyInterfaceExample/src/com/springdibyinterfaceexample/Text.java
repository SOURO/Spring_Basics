package com.springdibyinterfaceexample;

public interface Text {
	void setTextString(String textString);
	   String getTextString();
}
