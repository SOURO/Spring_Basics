package com.springdibyinterfaceexample;

public interface Service {
	void setText(Text text);
	   Text getText();
}
